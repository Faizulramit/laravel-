<!DOCTYPE html>
<html>
<head>
	<title>login page</title>
	<link rel="stylesheet" href="/css/test.css">
</head>
<body>
	<h1>Login</h1>

	<form method="post" >
		<table>
			<tr>
				<td>Username</td>
				<td><input type="text" name="uname"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr>
				<td><input type="submit" name="submit" value="Submit"></td>
				<td></td>
			</tr>
		</table>
	</form>
</body>
</html><?php /**PATH F:\ATP3\Final\PROJECTfall_2019_20_laravel\lar\resources\views/index.blade.php ENDPATH**/ ?>