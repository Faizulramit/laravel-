<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class syllabu extends Model
{
    //
     protected $primaryKey = "id";
     public $timestamps = false;
}
